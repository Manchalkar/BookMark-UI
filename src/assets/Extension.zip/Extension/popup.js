//Add Button
let addBookMark = document.getElementById("addExtension");
let url=document.getElementById("itemurl");
let successMessage=document.getElementById("successMessage");
let note=document.getElementById("note");
/**
 * Add Event
 */
addBookMark.addEventListener("click", async () => {
    console.log(note.innerHTML)
    let myBody={
        "url":url.innerHTML,
        "note":note.value
    }
    const response = await fetch('https://bookmarkapi.azurewebsites.net/api/BookMark', {
        method: 'POST',
        body: JSON.stringify(myBody), // string or object
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': "chrome-extension://fnijkkofegnjdaaflemagipdnofajghh/"
        }
      }).then((data)=>{
          successMessage.innerHTML="Added Successfully";
      })

});


/**
 * Load current tabUrl on Extension load.
 */
window.onload = function() {
    chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
        url.innerHTML="";
        successMessage.innerHTML="";
        url.innerHTML=tabs[0].url;
    });
  }
